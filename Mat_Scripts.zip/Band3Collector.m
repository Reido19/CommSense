
function eNodeBOutput=Band3Collector() 

radiolist = findsdru;
radio = comm.SDRuReceiver('Platform',radiolist.Platform, 'IPAddress', radiolist.IPAddress);
radio.MasterClockRate = 100e6;
radio.DecimationFactor = 4;
radio.ChannelMapping = [1];     % Receive signals from both channels
radio.CenterFrequency = 1862.1e6; %874.3MHz, 1810.1MHz
radio.Gain = 30;
radio.SamplesPerFrame = 125000; % Sampling rate is 1.92 MHz. LTE frames are 10 ms long
radio.OutputDataType = 'double';
radio.EnableBurstMode = true;
radio.NumFramesInBurst = 10; %4;
radio.OverrunOutputPort = true;

%% Capture Signal

burstCaptures = zeros(125000,10,1);

len = 0;
for frame = 1:10
    while len == 0
        [data,len,lostSamples] = step(radio);
        burstCaptures(:,frame,:) = data;
    end
    len = 0;
end
release(radio);

eNodeBOutput = reshape(burstCaptures,[],2);

end
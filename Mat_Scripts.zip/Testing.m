
% Loop to collect multiple sets of LTE DATA
headers = {'1','2','3','4','5','6','7','8','9','10','11','12','13','14','Target'};
num_data_captures = 10;
extra1 = ones(num_data_captures*600,1);
extra0 = zeros(num_data_captures*600,1);
dataDump = [];

for n = 1:num_data_captures

    % %Function to Colled IQ Data
    IQ = Band3Collector();
    % %Matlab Receiver to Demodulated Data
    SIB1RecoveryExample;

    dataDump = [dataDump;hest(:,:,1)];
    pause(20);
end

dataDump = [dataDump,extra1];

fileName = ['../Data/Radio_Lab/','LTE_3_RL_big.csv'];
% csvwrite(fileName,'dataDump');
writematrix(dataDump,'LTE_3_RL_bigData.csv');
disp("CSV File Written")

